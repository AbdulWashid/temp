<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	class App extends CI_Controller{
		public function __construct() {
            parent::__construct();
			$driver = $this->session->userdata('driver');
			date_default_timezone_set('Asia/Kolkata');
			$drive = $this->db->select('status')->from('driver_tbl')->where('driver_id',$driver['driver_id'])->get()->row_array();
			if($drive['status'] == 0){
				redirect('login/logout');
			}
			if(empty($driver)){
				redirect('login');
			}
        }
		public function dashboard(){
			$data['back'] = 'No';
			$driver = $this->session->userdata('driver');
			$data['delivery_list'] = $this->app_model->getDeliveryByDriver($driver['driver_id']);
			$data['tankiBhariCount'] = $this->db->select_sum('tanki_bhari')->from('supply_tbl')->where(array('driver_id'=>$driver['driver_id'],'supply_date'=>date('Y-m-d')))->get()->row()->tanki_bhari;
			$data['tankikhaliCount'] = $this->db->select_sum('tanki_khali')->from('supply_tbl')->where(array('driver_id'=>$driver['driver_id'],'supply_date'=>date('Y-m-d')))->get()->row()->tanki_khali;
			$data['collectAmt'] = $this->db->select_sum('amount')->from('supply_tbl')->where(array('driver_id'=>$driver['driver_id'],'supply_date'=>date('Y-m-d')))->get()->row()->amount;
            $this->load->view('app/dashboard',$data);
		}

		public function searchArea(){
			$data['back'] = 'Yes';
			$this->form_validation->set_rules('supply_date','Supply Date','trim|required');
			$this->form_validation->set_rules('area_id','Area','trim|required');
			if($this->form_validation->run() == TRUE){
				$area_id = $this->input->post('area_id');
				$supply_date = $this->input->post('supply_date');
				$nor = $this->app_model->checkCustomerByArea($area_id);
				if($nor != 0){
					redirect('app/areaCustomer/'.$area_id.'/'.$supply_date);
				}else{
					$this->session->set_flashdata('msg','<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>No Customer Found this area.</div>');
					redirect('app/searchArea');
				}
			}else{
				$data['area_list'] = $this->area_model->getAreaList();
				$this->load->view('app/search-by-area',$data);
			}	
		}

		public function customerList(){
			$data['back'] = 'Yes';
			$driver = $this->session->userdata('driver');
			$data['customer_list'] = $this->app_model->getCustomerAddedByDriver($driver['driver_id']);
			$this->load->view('app/customer_list',$data);
		}

		public function addCustomer(){
			$data['back'] = 'Yes';
			$driver = $this->session->userdata('driver');
			$this->form_validation->set_rules('area_id','Area','trim|required');
			$this->form_validation->set_rules('customer_name','Customer Name','trim|required');
			$this->form_validation->set_rules('mobileno','Mobile Number','trim|required|regex_match[/^[6-9]\d{9}$/]');
			$this->form_validation->set_rules('type','Type','trim|required');
			$this->form_validation->set_rules('kane_charge','Per Kane Charge','trim|required');
			$this->form_validation->set_rules('address','Address','trim|required');
			if($this->form_validation->run() == TRUE){
				$data = array(
					'area_id' => $this->input->post('area_id'),
					'customer_name' => $this->input->post('customer_name'),
					'mobileno' => $this->input->post('mobileno'),
					'type' => $this->input->post('type'),
					'kane_charge' => $this->input->post('kane_charge'),
					'address' => $this->input->post('address'),
					'driver_id' => $driver['driver_id']
				);
				$this->customer_model->add($data);
				$this->session->set_flashdata('msg','customerAdd');
				redirect('app/addCustomer');
			}else{
				$data['area_list'] = $this->area_model->getAreaList();
				$this->load->view('app/add_customer',$data);
			}
		}
		

		public function areaCustomer($area_id,$supply_date){
			$data['back'] = 'Yes';
			$data['area'] = $this->app_model->getAreaNameById($area_id);
			$data['customer_list'] = $this->app_model->getSuppliedCustomerByAreaId($area_id);
			$data['supply_date'] = $supply_date;
			$this->load->view('app/area-customer',$data);
		}

		public function supplyTanki(){
			$data = array('success' => false,'messages' => array());
			$this->form_validation->set_rules('supply_date','Supply Date','trim|required');
			$this->form_validation->set_rules('customer_id','Customer Id','trim|required');
			$this->form_validation->set_rules('tanki_bhari','टंकी भरी','trim|required');
			$this->form_validation->set_rules('tanki_khali','टंकी खाली','trim|required');
			$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
			if($this->form_validation->run()){
				$driver = $this->session->userdata('driver');
				$customer_id = $this->input->post('customer_id');
				$supply_date = $this->input->post('supply_date');
				$customer = $this->db->select('kane_charge,due_amount,kane_stock')->from('customer_tbl')->where('customer_id',$customer_id)->get()->row_array();
				$res = $this->db->select('*')->from('supply_tbl')->where(array('customer_id'=>$customer_id,'supply_date'=>date('Y-m-d',strtotime($supply_date))))->get()->row_array();
				if($res == NULL){
					$amount = $this->input->post('amount');
					if($amount != '' && $amount > 0){
						$collectAmt = $amount;
					}else{
						$collectAmt = '0';
					}
					$tanki_bhari = $this->input->post('tanki_bhari');
					$tanki_khali = $this->input->post('tanki_khali');
					$kane_stock = $customer['kane_stock'] + $tanki_bhari - $tanki_khali;
					if($customer['kane_stock'] >= $tanki_khali){
						$tankiTotal = $customer['kane_charge'] * $tanki_bhari;
						$due_amount = $customer['due_amount'] + $tankiTotal - $collectAmt;
						$due_amount2 = $customer['due_amount'] + $tankiTotal;
						if($due_amount2 >= $collectAmt){
							$data = array(
								'customer_id' => $customer_id,
								'tanki_bhari' => $tanki_bhari,
								'tanki_khali' => $tanki_khali,
								'stock' => $kane_stock,
								'per_kane_amt' => $customer['kane_charge'],
								'amount' => $this->input->post('amount'),
								'driver_id' => $driver['driver_id'],
								'supply_date' => $this->input->post('supply_date')
							);
							$this->db->insert('supply_tbl',$data);
							$this->db->insert('supplymore_tbl',$data);
							
							$this->db->set(array('due_amount'=>$due_amount,'kane_stock'=>$kane_stock))->where('customer_id',$customer_id)->update('customer_tbl');
							if($amount != '' && $amount > 0){
								$coll = array(
									'customer_id' => $customer_id,
									'collect_amount' => $amount,
									'balance' => $due_amount,
									'collect_date' => date('Y-m-d',strtotime($supply_date)),
									'driver_id' => $driver['driver_id']
								);
								$this->db->insert('collection_tbl',$coll);
							}
							$data['success'] = true;
						}else{
							$data['success'] = 'greaterAmt';
						}
						
					}else{
						$data['success'] = 'greater';
					}
					
				}else{
					$data['success'] = null;
				}
				
			}else{
				foreach($_POST as $key => $value){
					$data['messages'][$key] = form_error($key);
				}
			}

			echo json_encode($data);
		}

		public function supplyMoreTanki(){
			$data = array('success' => false,'messages' => array());
			$this->form_validation->set_rules('supply_date','Supply Date','trim|required');
			$this->form_validation->set_rules('customer_id','Customer Id','trim|required');
			$this->form_validation->set_rules('tanki_bhari2','टंकी भरी','trim|required');
			$this->form_validation->set_rules('tanki_khali','टंकी खाली','trim|required');
			$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
			if($this->form_validation->run()){
				$driver = $this->session->userdata('driver');
				$customer_id = $this->input->post('customer_id');
				$supply_date = $this->input->post('supply_date');
				$customer = $this->db->select('kane_charge,due_amount,kane_stock')->from('customer_tbl')->where('customer_id',$customer_id)->get()->row_array();
				$res = $this->db->select('*')->from('supply_tbl')->where(array('customer_id'=>$customer_id,'supply_date'=>date('Y-m-d',strtotime($supply_date))))->get()->row_array();
				
				$amount = $this->input->post('amount');
				if($amount != '' && $amount > 0){
					$collectAmt = $amount;
				}else{
					$collectAmt = '0';
				}
				$tanki_bhari = $this->input->post('tanki_bhari2');
				$tanki_khali = $this->input->post('tanki_khali');
				$kane_stock = $customer['kane_stock'] + $tanki_bhari - $tanki_khali;
				if($customer['kane_stock'] >= $tanki_khali){
					$tankiTotal = $customer['kane_charge'] * $tanki_bhari;
					$due_amount = $customer['due_amount'] + $tankiTotal - $collectAmt;
					$due_amount2 = $customer['due_amount'] + $tankiTotal;
					if($due_amount2 >= $collectAmt){
						$data = array(
							'customer_id' => $customer_id,
							'tanki_bhari' => $tanki_bhari,
							'tanki_khali' => $tanki_khali,
							'stock' => $kane_stock,
							'per_kane_amt' => $customer['kane_charge'],
							'amount' => $this->input->post('amount'),
							'driver_id' => $driver['driver_id'],
							'supply_date' => $this->input->post('supply_date')
						);
						$this->db->insert('supplymore_tbl',$data);
						$this->db->set(array('due_amount'=>$due_amount,'kane_stock'=>$kane_stock))->where('customer_id',$customer_id)->update('customer_tbl');
	
						/* Supply Update */
						$uptanki_bhari = $res['tanki_bhari'] + $tanki_bhari;
						$uptanki_khali = $res['tanki_khali'] + $tanki_khali;
						$upkane_stock = $kane_stock;
						$upcollectAmt = $res['amount'] + $collectAmt;
						$updArr = array(
							'tanki_bhari' => $uptanki_bhari,
							'tanki_khali' => $uptanki_khali,
							'stock' => $upkane_stock,
							'amount' => $upcollectAmt,
						);
						$this->db->set($updArr)->where(array('customer_id'=>$customer_id,'supply_date'=>date('Y-m-d',strtotime($supply_date))))->update('supply_tbl');
						/* Supply Update */
						if($amount != '' && $amount > 0){
							$coll = array(
								'customer_id' => $customer_id,
								'collect_amount' => $amount,
								'balance' => $due_amount,
								'collect_date' => date('Y-m-d',strtotime($supply_date)),
								'driver_id' => $driver['driver_id']
							);
							$this->db->insert('collection_tbl',$coll);
						}
						$data['success'] = true;
					}else{
						$data['success'] = 'greaterAmt';
					}
					
				}else{
					$data['success'] = 'greater';
				}
			}else{
				foreach($_POST as $key => $value){
					$data['messages'][$key] = form_error($key);
				}
			}

			echo json_encode($data);
		}

		public function customerReport(){
			$data['back'] = 'Yes';
			$this->form_validation->set_rules('customer_id','Customer','trim|required');
			$this->form_validation->set_rules('from_date','From Date','trim|required');
			$this->form_validation->set_rules('to_date','To Date','trim|required');
			if($this->form_validation->run() == TRUE){
				$customer_id = $this->input->post('customer_id');
				$from_date = $this->input->post('from_date');
				$to_date = $this->input->post('to_date');
				$data['customer_id'] = $customer_id;
				$data['from_date'] = $from_date;
				$data['to_date'] = $to_date;
				$data['customer_report'] = $this->app_model->getCustomerReportByDate($customer_id,$from_date,$to_date);
				$data['customer_list'] = $this->db->select('customer_id,customer_name')->from('customer_tbl')->where('status','1')->order_by('customer_id','DESC')->get()->result_array();
				$this->load->view('app/customer-report',$data);
			}else{
				$data['customer_id'] = '';
				$data['from_date'] = date('Y-m-01');
				$data['to_date'] = date('Y-m-d');
				$data['customer_report'] = '';
				$data['customer_list'] = $this->db->select('customer_id,customer_name')->from('customer_tbl')->where('status','1')->order_by('customer_id','DESC')->get()->result_array();
				$this->load->view('app/customer-report',$data);
			}
		}

		public function offlineSupplyReport(){
			$data['back'] = 'Yes';
			$driver = $this->session->userdata('driver');
			$this->form_validation->set_rules('from_date','From Date','trim|required');
			$this->form_validation->set_rules('to_date','To Date','trim|required');
			if($this->form_validation->run() == TRUE){
				$from_date = $this->input->post('from_date');
				$to_date = $this->input->post('to_date');
				$data['from_date'] = $from_date;
				$data['to_date'] = $to_date;
				$data['supply_report'] = $this->app_model->getOfflineSupplyReportByDate($driver['driver_id'],$from_date,$to_date);
				$this->load->view('app/offline-supply-report',$data);
			}else{
				$data['from_date'] = date('Y-m-01');
				$data['to_date'] = date('Y-m-d');
				$data['supply_report'] = '';
				$this->load->view('app/offline-supply-report',$data);
			}
		}

		public function profile(){
			$data['back'] = 'Yes';
			$driver = $this->session->userdata('driver');
			$data['driver'] = $this->db->select('*')->from('driver_tbl')->where('driver_id',$driver['driver_id'])->get()->row_array();
			$this->load->view('app/profile',$data);
		}

		public function supplyDetail($customer_id,$supply_date){
			$data['back'] = 'Yes';
			$data['customer'] = $this->db->select('customer_name')->from('customer_tbl')->where('customer_id',$customer_id)->get()->row_array();
			$data['customer_report'] = $this->db->select('*')->from('supplymore_tbl')->where(array('customer_id'=>$customer_id,'supply_date'=>$supply_date))->get()->result_array();
			$this->load->view('app/supply-detail',$data);
		}

		public function supplyOffline(){
			$data['back'] = 'Yes';
			$driver = $this->session->userdata('driver');
			$this->form_validation->set_rules('tanki_bhari','टंकी भरी','trim|required');
			$this->form_validation->set_rules('amount','अमाउंट','trim|required');
			$this->form_validation->set_rules('pay_type','Payment Type','trim|required');
			if($this->form_validation->run() == TRUE){
				$nor = $this->db->select('oid')->from('offlinesupply_tbl')->where(array('driver_id'=>$driver['driver_id'],'supply_date' => date('Y-m-d')))->get()->num_rows();
				$data = array(
					'driver_id' => $driver['driver_id'],
					'tanki_bhari' => $this->input->post('tanki_bhari'),
					'amount' => $this->input->post('amount'),
					'pay_type' => $this->input->post('pay_type'),
					'supply_date' => date('Y-m-d')
				);
				
				$this->app_model->addOfflineSupply($data);
				if($nor == 0){
					$insArr = array(
						'driver_id' => $driver['driver_id'],
						'total_tanki' => $this->input->post('tanki_bhari'),
						'total_amount' => $this->input->post('amount'),
						'supply_date' => date('Y-m-d')
					);
					$this->db->insert('offlinesupplytotal_tbl',$insArr);
				}else{
					$total = $this->db->select_sum('tanki_bhari')->select_sum('amount')->from('offlinesupply_tbl')->where(array('driver_id'=>$driver['driver_id'],'supply_date' => date('Y-m-d')))->get()->row_array();
					$updArr = array(
						'total_tanki' => $total['tanki_bhari'],
						'total_amount' => $total['amount']
					);
					$this->db->set($updArr)->where(array('driver_id'=>$driver['driver_id'],'supply_date' => date('Y-m-d')))->update('offlinesupplytotal_tbl');
				}
				$this->session->set_flashdata('msg','offlineAdd');
				redirect('app/supplyOffline');
			}else{
				$data['area_list'] = $this->area_model->getAreaList();
				$this->load->view('app/add-offline-supply',$data);
			}
		}
		
	}
?>