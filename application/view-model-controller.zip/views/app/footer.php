    <script src="<?php echo base_url('assets/frontend/js/'); ?>jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url('assets/'); ?>bower_components/jquery-ui/jquery-ui.min.js"></script>
    <script src="<?php echo base_url('assets/frontend/js/'); ?>bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url('assets/'); ?>js/sweetalert2.js"></script>
    <script src="<?php echo base_url('assets/'); ?>bower_components/select2/dist/js/select2.full.min.js"></script>
    <script src="<?php echo base_url('assets/frontend/js/'); ?>fontawesome.min.js"></script>
    <script src="<?php echo base_url('assets/frontend/js/'); ?>otp.js"></script>
    <?php 
        if(!empty($this->session->flashdata('msg'))){
            if($this->session->flashdata('msg') == 'customerAdd'){
                ?>
                <script>
                    Swal.fire('Customer Added Successfully.', '', 'success').then( () => {
                        window.location.href = '<?php echo base_url('app/customerList'); ?>';
                    })
                </script>
                <?php
            }

            if($this->session->flashdata('msg') == 'offlineAdd'){
                ?>
                <script>
                    Swal.fire('Tanki Supply Successfully.', '', 'success').then( () => {
                        window.location.href = '<?php echo base_url('app/supplyOffline'); ?>';
                    })
                </script>
                <?php
            }

            
        }
    ?>
    <script>  
        $(window).on('load', function() {
			$('#preloader').fadeOut('slow',function(){$(this).remove();});
		})
    </script>
    <script>
    $(document).ready(function () {
        $(".supplyForm").submit(function () {
            $(".supplyBtn").css("pointer-events","none");
        });
        $(".supplyForm2").submit(function () {
            $(".supplyBtn2").css("pointer-events","none");
        });
        
        $(".addCustomerForm").submit(function () {
            $(".addCustomerBtn2").css("pointer-events","none");
        });

        $("input").click(function(){
            $(".supplyBtn").css("pointer-events","auto");
            $(".supplyBtn2").css("pointer-events","auto");
        });
        
    });
</script>
    <script>
        $(document).ready(function(){
            $(document).on("click",".supplyKaneBtn",function(e){
                e.preventDefault();
                var customer_id = $(this).attr('href');
                var stock = $(this).attr('stock');
                var due = $(this).attr('due');
                $('#customer_id').val(customer_id);
                //$('.tanki_khali').val(stock);
                $('.stackCount').html(stock);
                $('.dueAmount').html(due);
            });
            
            $(document).on("click",".supplyKaneBtn2",function(e){
                e.preventDefault();
                var customer_id = $(this).attr('href');
                var stock = $(this).attr('stock');
                var due = $(this).attr('due');
                $('#customer_id2').val(customer_id);
                //$('.tanki_khali').val(stock);
                $('.stackCount2').html(stock);
                $('.dueAmount2').html(due);
            });
        });

        $('#supplyFormId').submit(function(e){
            e.preventDefault();
            var me = $(this);
            $.ajax({
                url:me.attr('action'),
                type:'post',
                data:me.serialize(),
                dataType:'json',
                success:function(response){
                    if(response.success == true){
                        Swal.fire('Tanki Supply Successfully.', '', 'success').then( () => {
                            window.location.reload();
                        })
                    }else if(response.success == 'greater'){
                        Swal.fire('Thanki Khali Greater Stock', '', 'error');
                    }else if(response.success == 'greaterAmt'){
                        Swal.fire('Collect Amount Greater Due Amount', '', 'error');
                    }else{
                        $.each(response.messages,function(key,value){
                            var element = $('#' + key);
                            element.closest('div.form-group')
                            .removeClass('has-error')
                            .addClass(value.length > 0 ? 'has-error' : 'has-success')
                            .find('.text-danger')
                            .remove();

                            element.after(value);
                        });
                    }
                }
                
            });
        });
        
        $('#supplyFormId2').submit(function(e){
            e.preventDefault();
            var me = $(this);
            $.ajax({
                url:me.attr('action'),
                type:'post',
                data:me.serialize(),
                dataType:'json',
                success:function(response){
                    if(response.success == true){
                        Swal.fire('Supply More Tanki Successfully.', '', 'success').then( () => {
                            window.location.reload();
                        })
                    }else if(response.success == 'greater'){
                        Swal.fire('Thanki Khali Greater Stock', '', 'error');
                    }else if(response.success == 'greaterAmt'){
                        Swal.fire('Collect Amount Greater Due Amount', '', 'error');
                    }else{
                        $.each(response.messages,function(key,value){
                            var element = $('#' + key);
                            element.closest('div.form-group')
                            .removeClass('has-error')
                            .addClass(value.length > 0 ? 'has-error' : 'has-success')
                            .find('.text-danger')
                            .remove();

                            element.after(value);
                        });
                    }
                }
                
            });
        });

    </script>    
    <script>
        $(function(){
            $( "#payment_date" ).datepicker({ 
                dateFormat: 'dd-mm-yy' 
            });
        });
        $(function () {
            $('.select2').select2();
        })
    </script>
    <script>
        function goBack() {
            window.history.back();
        }
        function myFunction(type){
            var input, filter, ul, li, a, i, txtValue;
            
            if(type == 'non_sup'){
                input = document.getElementById("myInput");
                filter = input.value.toUpperCase();
                ul = document.getElementById("my_con");
                li = ul.getElementsByClassName("deliveryCard-nonsup");
                for (i = 0; i < li.length; i++) {
                    a = li[i].getElementsByTagName("strong")[0];
                    txtValue = a.textContent || a.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        li[i].style.display = "";
                    } else {
                        li[i].style.display = "none";
                    }
                }    
            }else{
                input = document.getElementById("myInput2");
                filter = input.value.toUpperCase();
                ul = document.getElementById("my_con2");
                li = ul.getElementsByClassName("deliveryCard-sup");
                
                for (i = 0; i < li.length; i++) {
                    a = li[i].getElementsByTagName("strong")[0];
                    txtValue = a.textContent || a.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        li[i].style.display = "";
                    } else {
                        li[i].style.display = "none";
                    }
                }  
            }
            
        }
    </script>
    
    
</body>
</html>