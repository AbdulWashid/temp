<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arihant Aqua</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/'); ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/'); ?>fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/'); ?>solid.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/'); ?>brands.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/'); ?>style.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>bower_components/select2/dist/css/select2.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <style>
        .form-group{
            margin-bottom:7px !important;
        }
        .form-group label{
            font-size:13px;
            margin-bottom:3px;
        }
        .form-control{
            font-size:13px;
        }
        .text-danger p{
            font-size:13px;
            margin-bottom:0px;
        }
        .table td, .table th{
            padding:4px 3px 4px 10px;
            font-size:12px;
        }
        .cmnInp{
            width:50px;
        }
    </style>
</head>
<body>

    <?php include('header2.php'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 p-0">
                <div class="text-center">
                    <h4 style="margin-top:15px;margin-bottom:10px;">Supply Edit</h4>
                </div>
                
                <div>
                    <form action="#<?php echo base_url('app/supplyOffline'); ?>" method="POST" class="addCustomerForm supplyeditForm">
                        <div class="text-center">
                            <h6 style="color:#d10000;font-weight:bold;margin-bottom:15px;">Old Stock <?php echo date('d-m-Y',strtotime($previous['supply_date'])); ?> :- <?php echo $previous['stock']; ?></h6>
                        </div>
                        <input type="hidden" name="old_stock" value="<?php echo $previous['stock']; ?>" id="old_stock">
                        <table class="table table-bordered edit_tbl" width="100%"  id="my-tbody">
                            <thead>
                                <tr>
                                    <th>क्र.</th>
                                    <th>टंकी भरी</th>
                                    <th>टंकी खाली</th>
                                    <th>स्टॉक</th>
                                    <th>अमाउंट</th>
                                </tr>
                            </thead>
                            <tbody id="">
                                
                                <?php 
                                    if(!empty($supply_list)){
                                        $i = 1;
                                        foreach($supply_list as $value){
                                            ?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td class="bhari_tanki"><input type="text" value="<?php echo $value['tanki_bhari']; ?>" class="cmnInp tankiBhari"></td>
                                                <td class="khali_tanki"><input type="text" value="<?php echo $value['tanki_khali']; ?>" class="cmnInp tankiKhali"></td>
                                                <td><input type="text" value="<?php echo $value['stock']; ?>" class="cmnInp" disabled></td>
                                                <td class="tanki_amount"><input type="text" value="<?php echo $value['amount']; ?>" class="cmnInp tankiAmount"></td>
                                            </tr>
                                            <?php
                                            $i++;
                                        }
                                    }
                                ?>
                                
                            </tbody>
                        </table>
                        <p class="text-danger text-center error_con"></p>
                        <button type="submit" class="btn btn-primary btn-block btn-md addCustomerBtn2 mt-4">Supply Edit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include('footer.php'); ?>